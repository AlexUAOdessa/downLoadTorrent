@echo restart explorer
@taskkill /f /IM explorer.exe
@start explorer.exe
@echo Done!
exit